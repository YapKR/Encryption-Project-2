# app.py

from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

mysql = MySQL(app)
bcrypt = Bcrypt(app)

@app.route('/')
def index():
    return render_template('Auth.html')

@app.route('/home')
def home():
    return render_template('Homepage.html')

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password_candidate = request.form['password']
        cur = mysql.connection.cursor()
        result = cur.execute("SELECT * FROM users WHERE username = %s", [username])
        if result > 0:
            data = cur.fetchone()
            password = data[3]  # Assuming password is the fourth column
            if bcrypt.check_password_hash(password, password_candidate):
                session['logged_in'] = True
                session['username'] = username
                return redirect(url_for('home'))
            else:
                flash('Invalid login. Please check your username and password.')
                return redirect(url_for('index'))
        else:
            flash('Username not found. Please register first.')
            return redirect(url_for('index'))
        cur.close()
    return redirect(url_for('index'))

@app.route('/signup', methods=['POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm-password']
        
        # Check if username or email already exists
        cur = mysql.connection.cursor()
        user_check = cur.execute("SELECT * FROM users WHERE username = %s OR email = %s", (username, email))
        
        if user_check > 0:
            flash('Username or email already exists. Please choose another.')
            return redirect(url_for('index'))
        
        if password == confirm_password:
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
            cur.execute("INSERT INTO users(username, email, password) VALUES(%s, %s, %s)", (username, email, hashed_password))
            mysql.connection.commit()
            cur.close()
            flash('You are now registered and can log in.')
            return redirect(url_for('index'))
        else:
            flash('Passwords do not match.')
            return redirect(url_for('index'))
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
