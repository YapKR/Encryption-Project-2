# config.py

class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = '8zfZngvB$'
    MYSQL_DB = 'project_encryption'
    SECRET_KEY = '8zfZngvB$'
