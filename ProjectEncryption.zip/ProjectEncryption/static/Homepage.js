// Homepage.js
document.getElementById('logoutBtn').addEventListener('click', function() {
    window.location.href = '/logout';
});
